/*
BILIBILI:技术宅物语
*/
#ifndef __LCDFONT_H
#define __LCDFONT_H 	   

extern const unsigned char ascii_1608[][16];
extern const unsigned char ascii_3216[][64];


#endif
