#pragma once


#include "esp_tts.h"
extern const esp_tts_voice_t  esp_tts_voice_template;
