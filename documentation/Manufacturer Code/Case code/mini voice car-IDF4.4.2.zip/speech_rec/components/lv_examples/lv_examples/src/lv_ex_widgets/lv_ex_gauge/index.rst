C
^

Simple Gauge 
""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_gauge/lv_ex_gauge_1.png
  :alt: Simple Gauge example in LVGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_gauge/lv_ex_gauge_1.c
      :language: c

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_gauge/lv_ex_gauge_2.png
  :alt: Gauge with needle images in LVGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_gauge/lv_ex_gauge_2.c
      :language: c
      
MicroPython
^^^^^^^^^^^

No examples yet.
