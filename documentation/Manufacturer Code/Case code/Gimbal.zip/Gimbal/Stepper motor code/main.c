/*---------------------------------------------------------------------*/
/* --- STC MCU Limited ------------------------------------------------*/
/* --- STC 1T Series MCU Demo Programme -------------------------------*/
/* --- Mobile: (86)13922805190 ----------------------------------------*/
/* --- Fax: 86-0513-55012956,55012947,55012969 ------------------------*/
/* --- Tel: 86-0513-55012928,55012929,55012966 ------------------------*/
/* --- Web: www.STCMCU.com --------------------------------------------*/
/* --- Web: www.STCMCUDATA.com  ---------------------------------------*/
/* --- QQ:  800003751 -------------------------------------------------*/
/* ���Ҫ�ڳ�����ʹ�ô˴���,���ڳ�����ע��ʹ����STC�����ϼ�����            */
/*---------------------------------------------------------------------*/

#include	"config.h"
#include	"GPIO.h"
#include	"delay.h"
#include	"timer.h"

/***************	����˵��	****************

����ʱ, ѡ��ʱ�� 6MHz (�����������ļ�"config.h"���޸�).

******************************************/

/*************	���س�������	**************/


/*************	���ر�������	**************/

/*************	���غ�������	**************/


/*************  �ⲿ�����ͱ������� *****************/

#define PIN_A 1
#define PIN_A_ 2
#define PIN_B 3
#define PIN_B_ 4

#define BIT_A P14
#define BIT_A_ P13
#define BIT_B P12
#define BIT_B_ P11

#define step_ms 1

#define position_max 630
#define position_multiple 35

u16 position_present = 0;
u16 position_target = 0;
u16 position_value = 0; //λ��ֵ0-1000
u16 tm0_count = 0;	 //251 - 754 - 1257
u16 send_ready = 0;


//����
#define FOSC        6000000UL
#define BRT         (65536 - FOSC / 115200 / 4)

bit busy;
char wptr;
char rptr;
char buffer[16];

void UartIsr() interrupt 4
{
    if (TI)
    {
        TI = 0;
        busy = 0;
    }
    if (RI)
    {
        RI = 0;
        buffer[wptr++] = SBUF;
        wptr &= 0x0f;
    }
}

void UartInit()
{
    SCON = 0x50;
    T2L = BRT;
    T2H = BRT >> 8;
    AUXR = 0x15;
    wptr = 0x00;
    rptr = 0x00;
    busy = 0;
}

void UartSend(char dat)
{
    while (busy);
    busy = 1;
    SBUF = dat;
}

void UartSendStr(char *p)
{
    while (*p)
    {
        UartSend(*p++);
    }
}

void UartSendnumber(u16 num)
{
	if(num/10000)
		UartSend(num/10000+48);
	num = num % 10000;
	if(num/1000)
		UartSend(num/1000+48);
	num = num % 1000;
	if(num/100)
		UartSend(num/100+48);
	num = num % 100;
	if(num/10)
		UartSend(num/10+48);
	UartSend(num%10+48);
	UartSend('\r');
	UartSend('\n');
}
//�������
void delay(u16 t)
{
	u16 i;
	while(t--)
	{
		for(i=100; i>0 ;i--);
	}
}

void digitalWrite(u8 pin, u8 val)
{
	if(pin == PIN_A)
		BIT_A = val;
	if(pin == PIN_A_)
		BIT_A_ = val;
	if(pin == PIN_B)
		BIT_B = val;
	if(pin == PIN_B_)
		BIT_B_ = val;
}

void back(u16 count)
{
	while(count--)
	{
		digitalWrite(PIN_A,1);
		digitalWrite(PIN_A_,0);
		digitalWrite(PIN_B,0);
		digitalWrite(PIN_B_,0);
		delay(step_ms);
		
		digitalWrite(PIN_A,1);
		digitalWrite(PIN_A_,0);
		digitalWrite(PIN_B,1);
		digitalWrite(PIN_B_,0);
		delay(step_ms);
		
		digitalWrite(PIN_A,0);
		digitalWrite(PIN_A_,0);
		digitalWrite(PIN_B,1);
		digitalWrite(PIN_B_,0);
		delay(step_ms);
		
		digitalWrite(PIN_A,0);
		digitalWrite(PIN_A_,1);
		digitalWrite(PIN_B,1);
		digitalWrite(PIN_B_,0);
		delay(step_ms);
		
		digitalWrite(PIN_A,0);
		digitalWrite(PIN_A_,1);
		digitalWrite(PIN_B,0);
		digitalWrite(PIN_B_,0);
		delay(step_ms);
		
		digitalWrite(PIN_A,0);
		digitalWrite(PIN_A_,1);
		digitalWrite(PIN_B,0);
		digitalWrite(PIN_B_,1);
		delay(step_ms);
		
		digitalWrite(PIN_A,0);
		digitalWrite(PIN_A_,0);
		digitalWrite(PIN_B,0);
		digitalWrite(PIN_B_,1);
		delay(step_ms);
		
		digitalWrite(PIN_A,1);
		digitalWrite(PIN_A_,0);
		digitalWrite(PIN_B,0);
		digitalWrite(PIN_B_,1);
		delay(step_ms);

		if(position_present)
			position_present--;
	}
}

void front(u16 count)
{
	while(count--)
	{
		digitalWrite(PIN_A,1);
		digitalWrite(PIN_A_,0);
		digitalWrite(PIN_B,0);
		digitalWrite(PIN_B_,0);
		delay(step_ms);
		
		digitalWrite(PIN_A,1);
		digitalWrite(PIN_A_,0);
		digitalWrite(PIN_B,0);
		digitalWrite(PIN_B_,1);
		delay(step_ms);
		
		digitalWrite(PIN_A,0);
		digitalWrite(PIN_A_,0);
		digitalWrite(PIN_B,0);
		digitalWrite(PIN_B_,1);
		delay(step_ms);
		
		digitalWrite(PIN_A,0);
		digitalWrite(PIN_A_,1);
		digitalWrite(PIN_B,0);
		digitalWrite(PIN_B_,1);
		delay(step_ms);
		
		digitalWrite(PIN_A,0);
		digitalWrite(PIN_A_,1);
		digitalWrite(PIN_B,0);
		digitalWrite(PIN_B_,0);
		delay(step_ms);
		
		digitalWrite(PIN_A,0);
		digitalWrite(PIN_A_,1);
		digitalWrite(PIN_B,1);
		digitalWrite(PIN_B_,0);
		delay(step_ms);
		
		digitalWrite(PIN_A,0);
		digitalWrite(PIN_A_,0);
		digitalWrite(PIN_B,1);
		digitalWrite(PIN_B_,0);
		delay(step_ms);
		
		digitalWrite(PIN_A,1);
		digitalWrite(PIN_A_,0);
		digitalWrite(PIN_B,1);
		digitalWrite(PIN_B_,0);
		delay(step_ms);

		if(position_present < position_max)
			position_present++;
	}
}

void stop(void)
{
	digitalWrite(PIN_A,0);
	digitalWrite(PIN_A_,0);
	digitalWrite(PIN_B,0);
	digitalWrite(PIN_B_,0);
}

/******************** IO���ú��� **************************/
void	GPIO_config(void)
{
	GPIO_InitTypeDef	GPIO_InitStructure;		//�ṹ����
	GPIO_InitStructure.Pin  = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4;		//ָ��Ҫ��ʼ����IO,
	GPIO_InitStructure.Mode = GPIO_OUT_PP;		//ָ��IO������������ʽ,GPIO_PullUp,GPIO_HighZ,GPIO_OUT_OD,GPIO_OUT_PP
	GPIO_Inilize(GPIO_P1,&GPIO_InitStructure);	//��ʼ��

	GPIO_InitStructure.Pin  = GPIO_Pin_2 | GPIO_Pin_3;		//ָ��Ҫ��ʼ����IO, GPIO_Pin_0 ~ GPIO_Pin_7
	GPIO_InitStructure.Mode = GPIO_PullUp;		//ָ��IO������������ʽ,GPIO_PullUp,GPIO_HighZ,GPIO_OUT_OD,GPIO_OUT_PP
	GPIO_Inilize(GPIO_P3,&GPIO_InitStructure);	//��ʼ��
}


void TM0_Isr() interrupt 1
{
	tm0_count = 0;
	TR0 = 0;
}

void INT0_Isr() interrupt 0
{
    if (INT0)                                   //�ж������غ��½���
    {
		TL0 = 0;                                 //���趨ʱ����
    	TH0 = 0;
        TR0 = 1;
    }
    else
    {
        TR0 = 0;
		tm0_count = TH0 * 256 + TL0;
		//��ֵ
		if(tm0_count < 240)
			position_value = 65535;
		else if(tm0_count > 1260)
			position_value = 65535;
		else if(tm0_count < 250)
			position_value = 0;
		else if(tm0_count > 1250)
			position_value = 1000;
		else
			position_value = tm0_count - 250;

		position_target	= position_value / 16 * 10;//�ȳ�16���;��ȼ�����

		send_ready = 1;
    }
}

/******************** ������ **************************/
void main(void)
{
	u8 direction = 0;

	delay_ms(1000);
	GPIO_config();

	//��ʼ��IO�ж�
	IT0 = 0;                                    //ʹ��INT0�����غ��½����ж�
    EX0 = 1;                                    //ʹ��INT0�ж�
	//��ʼ����ʱ��
	TMOD = 0x01;                                //ģʽ1
    TL0 = 0;                                 //65536-6M/12 ��2us����һ��
    TH0 = 0;
    //TR0 = 1;                                    //������ʱ��
    ET0 = 1;                                    //ʹ�ܶ�ʱ���ж�
	//��ʼ������
	UartInit();
	ES = 1;
	//��ȫ���ж�
	EA = 1;	

	back(650);	
	position_target = 315;
	while(1)
	{
		if(position_present < position_target)
		{
			if(direction == 2)
				delay_ms(200);
			direction = 1;
			front(1);
		}
		if(position_present > position_target)
		{
			if(direction == 1)
				delay_ms(200);
			direction = 2;
			back(1);
		}
		else
		{
			stop();
			direction = 0;
		}
		/*if(send_ready)
		{
			UartSendnumber(tm0_count);
			send_ready = 0;
		}*/
	}
}




